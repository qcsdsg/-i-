# apple_python-
apple_python 官网自动监控爬虫


使用方法已经写在main.py文件中

注意事项
使用 selenium 时需要稍微配置一下环境, 需要有 chromedriver.exe,  这个版本要和谷歌浏览器的版本对应上
把 chromedriver.exe 文件粘贴在 python 安装路径的根目录 (也就是和 python.exe) 在同一个目录
这里我就先提供  92.0.4515.131 版本的驱动, 理论上  92.0.4515.xxx 的谷歌浏览器都是可以用的
注意一定要用谷歌浏览器

!!!注意, 安装python的时候记得看图片, 一定要勾选 add python 3.8 to PATH
驱动最新链接
http://npm.taobao.org/mirrors/chromedriver/

B站视频传送链接
https://www.bilibili.com/video/BV1Tg411c7C5#reply5424884699


BV1Tg411c7C5
